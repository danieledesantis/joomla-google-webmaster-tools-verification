<?php
/**
 * @package Google Webmaster Tools Verification for Joomla! 2.5 and Joomla! 3.0
 * @author Daniele De Santis http://www.danieledesantis.net
 * @copyright (C) 2015 - Daniele De Santis. All rights reserved
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
**/
defined ('_JEXEC') or die ( 'Restricted access');

jimport('joomla.plugin');

class plgSystemGoogleWebmasterToolsVerification extends JPlugin {
	
  public function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		$this->loadLanguage();
  }
  
  function onBeforeRender() {
		$app = JFactory::getApplication();
		$menu = $app->getMenu();
		$lang = JFactory::getLanguage();
	
		if ($menu->getActive() == $menu->getDefault($lang->getTag())) {
			$params = $this->params;
			$webmaster_tools = $params->get('gwtv_webmastertools');
			if($webmaster_tools) {
				$doc = JFactory::getDocument();
				$doc->setMetaData('google-site-verification', $webmaster_tools);
			}
		}	
  } 
	
}
?>